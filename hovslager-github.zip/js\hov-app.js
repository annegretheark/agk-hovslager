console.log("hov-app.js lastet");

let alleHovHester = [];

document.addEventListener("DOMContentLoaded", () => {

  kobleKnapp("leggTilKundeKnapp", "lagreKunde");
  kobleKnapp("lagreHestKnapp", "lagreHest");
  kobleKnapp("lagreJobbKnapp", "lagreJobbMedHestSjekk");
  kobleKnapp("lagFakturaKnapp", "lagHovFaktura");
  kobleKnapp("lagKreditnotaKnapp", "lagHovKreditnota");
  kobleKnapp("hentFakturaOversiktKnapp", "hentFakturaOversikt");
  kobleKnapp("eksporterFakturaExcelKnapp", "eksporterFakturaOversiktExcel");

  const jobbKunde = document.getElementById("jobbKunde");

  if (jobbKunde) {
    jobbKunde.addEventListener("change", async () => {
      await fyllJobbHesterForValgtKunde();
    });
  }

  startHovslager();
});

function kobleKnapp(id, funksjonsnavn) {

  const knapp = document.getElementById(id);

  if (!knapp) {
    return;
  }

  knapp.addEventListener("click", async () => {

    const fn = window[funksjonsnavn];

    if (typeof fn !== "function") {
      console.error("Mangler funksjon:", funksjonsnavn);
      alert("Programfeil: mangler funksjon " + funksjonsnavn);
      return;
    }

    await fn();
  });
}

async function startHovslager() {

  try {

    if (typeof hentKunder === "function") {
      await hentKunder();
    }

    await hentAlleHesterFraBase();

    await fyllJobbHesterForValgtKunde();

    if (typeof hentJobber === "function") {
      await hentJobber();
    }

    if (typeof fyllFakturaKunder === "function") {
      await fyllFakturaKunder();
    }

    if (typeof fyllKreditFakturaer === "function") {
      await fyllKreditFakturaer();
    }

    settDagensDato();

  } catch (e) {

    console.error(e);
    alert("Feil ved oppstart av hovslager-systemet.");
  }
}

function settDagensDato() {

  const jobbDato = document.getElementById("jobbDato");

  if (!jobbDato) {
    return;
  }

  const idag = new Date();

  const yyyy = idag.getFullYear();

  const mm = String(idag.getMonth() + 1).padStart(2, "0");

  const dd = String(idag.getDate()).padStart(2, "0");

  jobbDato.value = `${yyyy}-${mm}-${dd}`;
}

async function hentAlleHesterFraBase() {

  if (!window.supabaseClient) {
    console.error("Mangler supabaseClient");
    return;
  }

  const { data, error } = await window.supabaseClient
    .from("hester")
    .select("*")
    .order("navn", { ascending: true });

  if (error) {
    console.error("Feil ved henting av hester:", error);
    alert("Feil ved henting av hester.");
    return;
  }

  alleHovHester = data || [];
}

async function fyllJobbHesterForValgtKunde() {

  const kundeSelect = document.getElementById("jobbKunde");
  const hestSelect = document.getElementById("jobbHest");

  if (!kundeSelect || !hestSelect) {
    return;
  }

  const valgtKundeId = kundeSelect.value;

  hestSelect.innerHTML = `<option value="">Velg hest</option>`;

  if (!valgtKundeId) {
    return;
  }

  if (!alleHovHester || alleHovHester.length === 0) {
    await hentAlleHesterFraBase();
  }

  const hesterForKunde = alleHovHester.filter(h =>
    String(h.kunde_id) === String(valgtKundeId)
  );

  hesterForKunde.forEach(hest => {

    const option = document.createElement("option");

    option.value = hest.id;
    option.textContent = hest.navn;

    hestSelect.appendChild(option);
  });
}

async function lagreJobbMedHestSjekk() {

  const kundeSelect = document.getElementById("jobbKunde");
  const hestSelect = document.getElementById("jobbHest");

  const kundeId = kundeSelect ? kundeSelect.value : "";
  const hestId = hestSelect ? hestSelect.value : "";

  if (!kundeId) {
    alert("Velg kunde/eier først.");
    return;
  }

  if (!hestId) {
    alert("Velg hest.");
    return;
  }

  if (!alleHovHester || alleHovHester.length === 0) {
    await hentAlleHesterFraBase();
  }

  const valgtHest = alleHovHester.find(h =>
    String(h.id) === String(hestId)
  );

  if (!valgtHest) {
    alert("Fant ikke valgt hest.");
    return;
  }

  if (String(valgtHest.kunde_id) !== String(kundeId)) {
    alert("Denne hesten tilhører ikke valgt kunde/eier.");
    await fyllJobbHesterForValgtKunde();
    return;
  }

  if (typeof window.lagreJobb !== "function") {
    console.error("Mangler original lagreJobb-funksjon");
    alert("Programfeil: mangler lagreJobb.");
    return;
  }

  await window.lagreJobb();
}